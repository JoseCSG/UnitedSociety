//
//  Enums.swift
//  CustomTabView
//
//  Created by Alumno on 21/09/23.
//

import Foundation

enum Tab {
    case home
    case news
    case search
}
